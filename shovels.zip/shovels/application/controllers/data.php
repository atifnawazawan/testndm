<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class data extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        //$this->load->library('session');
        //$this->load->library('upload');
        //$this->load->helper('form');
        //$this->load->helper('url');
        //$this->load->helper('html');
        //	$this->load->database();
        $this->load->model('company_model');
        $this->load->model('Model_form');
        //  $this->load->model('signup_model');
        /*
                $this->load->model('Model_form');
                $this->load->model('Model_user');
                $this->load->model('Model_email');
                $this->load->library('form_validation');
                $this->load->library('pagination');
            */

        //load the login model
    }

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function companies()
    {
        //$this->load->view('welcome_message');

       // $this->session->sess_destroy();
        is_logged_in();
        $page=$this->input->get('page');
        if($page=='1'|$page==2) {
            $a['records'] = $this->company_model->get_companies();
        }


         elseif($page=='diesel'){
       $a['records'] = $this->company_model->get_diesel();
        $id=$this->input->get('id');

        $a['shov']=$this->company_model->company_data($id);

    }   else{
             $a['records'] = $this->company_model->get_pagerecord($page);

         }

        if($_SESSION['user_id'] == '1'){
            $this->load->view('admin/menus');}
        elseif($_SESSION['user_id'] == '2'){
            $this->load->view('admin/menus2');}
        elseif($_SESSION['user_id'] == '3'){
            $this->load->view('admin/menus3');}
        $this->load->view('company',$a);
        $this->load->view('admin/footer');
    }

    public function create(){
        is_logged_in();
        $this->company_model->getcreatedata();
        if($_SESSION['user_id'] == '1'){
            $this->load->view('admin/menus');}
        if($_SESSION['user_id'] == '2'){
            $this->load->view('admin/menus2');}
        if($_SESSION['user_id'] == '3'){
            $this->load->view('admin/menus3');}
        $this->load->view('admin/data');
        $this->load->view('admin/footer');
    }

    public function editcompany()
    {        is_logged_in();

        $a['records']=$this->company_model->company_data($this->input->get('id'));
        //$a['roles']=$this->data_model->getauthority();
        if($_SESSION['user_id'] == '1'){
            $this->load->view('admin/menus');}
        if($_SESSION['user_id'] == '2'){
            $this->load->view('admin/menus2');}
        if($_SESSION['user_id'] == '3'){
            $this->load->view('admin/menus3');}
        $this->load->view('company_edit',$a);
        $this->load->view('admin/footer');

    }
    public function editlocation()
    {        is_logged_in();

        $a['records']=$this->company_model->location_data($this->input->get('id'));
        //$a['roles']=$this->data_model->getauthority();
        if($_SESSION['user_id'] == '1'){
            $this->load->view('admin/menus');}
        if($_SESSION['user_id'] == '2'){
            $this->load->view('admin/menus2');}
        if($_SESSION['user_id'] == '3'){
            $this->load->view('admin/menus3');}
        $this->load->view('record_edit',$a);
        $this->load->view('admin/footer');

    }
    public function editcompanyrecord(){
        is_logged_in();
        $this->company_model->getproeditdata($this->input->post('compid'));

        // $this->protables();
    }

    public function editrecord(){
        is_logged_in();
        $this->company_model->edit_record_model($this->input->post('compid'));

        // $this->protables();
    }

    public function companydata(){
        is_logged_in();
        $this->company_model->add_details();
        $id=$this->input->get('id');
        $a['data']=$this->company_model->view_companydata($id);
        $a['records']=$this->company_model->company_data($this->input->get('id'));

        if($_SESSION['user_id'] == '1'){
            $this->load->view('admin/menus');}
        if($_SESSION['user_id'] == '2'){
            $this->load->view('admin/menus2');}
        if($_SESSION['user_id'] == '3'){
            $this->load->view('admin/menus3');
        }
        $this->load->view('company_data_view',$a);
        $this->load->view('admin/footer');

    }
}
