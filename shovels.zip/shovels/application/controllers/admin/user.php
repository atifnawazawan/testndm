<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class user extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        //$this->load->library('session');
        //$this->load->library('upload');
        //$this->load->helper('form');
        //$this->load->helper('url');
        //$this->load->helper('html');
        //	$this->load->database();
        $this->load->model('data_model');
      //  $this->load->model('signup_model');
        /*
                $this->load->model('Model_form');
                $this->load->model('Model_user');
                $this->load->model('Model_email');
                $this->load->library('form_validation');
                $this->load->library('pagination');
            */

        //load the login model
    }

    public function index()
    {

        //is_not_logged_in();
        $head = array('success_msg' => '', 'error_msg' => '');
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            //echo $this->db->from('admin')->where('username',$this->input->post('userEmail'))->where('password',$this->input->post('userPassword'))->get()->num_rows();exit;
            $loginfo=$this->data_model->getloginfo($this->input->post('user_Name'), $this->input->post('user_Password'));
            if($loginfo) {
                foreach ($loginfo as $record)
                    if ($record['authorityId'] == 1 & $record['enabled'] != 0) {
                        $this->session->set_userdata('user_id', 1);
                        $this->session->set_userdata('name', 'SuperAdmin');
                        $_SESSION['is_admin'] = 'yes';
                        $_SESSION['user_id'] = '1';
                        $_SESSION['name'] = $record['userName'];
                        redirect('admin/user/dashboard');
                    }
                if ($record['authorityId'] == 2 & $record['enabled'] != 0) {
                    $this->session->set_userdata('user_id', 2);
                    $this->session->set_userdata('name', $record['userName']);
                    $_SESSION['is_admin'] = 'yes';
                    //  $_SESSION['user_id'] = '1';
                    redirect('admin/user/dashboard2');
                }
                if ($record['authorityId'] == 3 & $record['enabled'] != 0) {
                    $this->session->set_userdata('user_id', 3);
                    $this->session->set_userdata('name', $record['userName']);
                    $_SESSION['is_admin'] = 'yes';
                    //  $_SESSION['user_id'] = '1';
                    redirect('admin/user/dashboard3');
                } else {
                    $head['error_msg'] = 'Enter correct Credentials';
                }
            }
        }
        $this->load->view('admin/login', $head);
    }
    public function dashboard(){

        is_logged_in();
        $this->load->view('admin/menus');
        $this->load->view('admin/dashboard');
        $this->load->view('admin/footer');

    }

    public function dashboard3(){
        is_logged_in();
        $this->load->view('admin/menus3');
        $this->load->view('admin/dashboard');
        $this->load->view('admin/footer');
    }
    public function page(){
        is_logged_in();
        is_admin();
        $this->load->view('admin/menus');
        $this->load->view('admin/page');
        $this->load->view('admin/footer');

    }

    public function dashboard2(){
        is_logged_in();
        $this->load->view('admin/menus2');
        $this->load->view('admin/dashboard');
        $this->load->view('admin/footer');
    }

    public function data(){
    is_logged_in();
    $a['records']=$this->data_model->pagedata($this->input->get('page'));
    if($_SESSION['user_id'] == '1'){
        $this->load->view('admin/menus');}
    if($_SESSION['user_id'] == '2'){
        $this->load->view('admin/menus2');}
    if($_SESSION['user_id'] == '3'){
        $this->load->view('admin/menus3');}
    $this->load->view('admin/data',$a);
    $this->load->view('admin/footer');
}
    public function create(){
        is_logged_in();
        $this->data_model->getcreatedata();
        if($_SESSION['user_id'] == '1'){
            $this->load->view('admin/menus');}
        if($_SESSION['user_id'] == '2'){
            $this->load->view('admin/menus2');}
        if($_SESSION['user_id'] == '3'){
            $this->load->view('admin/menus3');}        $this->load->view('admin/data');
        $this->load->view('admin/footer');
    }
    public function deleteuser()
    {
        is_logged_in();
        $this->data_model->removeuser( $this->input->get('id'));


    }
    public function editprorecord(){
        is_logged_in();
        $this->data_model->getproeditdata($this->input->post('userid'));

       // $this->protables();
    }
    public function edituser()
    {        is_logged_in();

        $a['records']=$this->data_model->getuserlogindata($this->input->get('id'));
        $a['roles']=$this->data_model->getauthority();
        if($_SESSION['user_id'] == '1'){
            $this->load->view('admin/menus');}
        if($_SESSION['user_id'] == '2'){
            $this->load->view('admin/menus2');}
        if($_SESSION['user_id'] == '3'){
            $this->load->view('admin/menus3');}
        $this->load->view('admin/edit',$a);
        $this->load->view('admin/footer');

    }
    public function blockusers(){
        is_logged_in();
        $this->data_model->blockuser($this->input->get('id'));
    }
    public function unblockusers(){
        is_logged_in();
    $this->data_model->unblockuser($this->input->get('id'));
}
}