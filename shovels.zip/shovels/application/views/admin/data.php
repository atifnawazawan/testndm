
<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Tables
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a>
                    </li>
                    <li class="active">
                        <i class="fa fa-table"></i> Tables
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <?php if ($this->input->get('page')==1)
            {?>
                <div class="col-lg-12">
                    <h2>User Table</h2>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>password</th>
                                <th>Authority</th>
                                <th>action</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php foreach ($records as $record){ ?>


                                        <?php if($this->session->userdata('user_id')==1){if($record['enabled']=='1'){?>

                                    <td><?php echo $record['userName']?></td>
                                    <td><?php echo $record['password']?></td>
                                    <td><?php echo $record['authority']?></td>

                                    <td>
                                            <a href="<?php echo base_url();?>index.php/admin/user/deleteuser?id=<?php echo $record['id']?>"
                                            >     <i class="glyphicon glyphicon-trash"></i>  </a>
                                            <a href="<?php echo base_url();?>index.php/admin/user/edituser?id=<?php echo $record['id']?>"> <i class="glyphicon glyphicon-pencil"></i></a>

                                            <a href="<?php echo base_url();?>index.php/admin/user/blockusers?id=<?php echo $record['id']?>"><button class="btn btn-default" >Block</button></a></td>

                                        <?php }elseif($record['enabled']=='0'){?>
                                            <td><?php echo $record['userName']?></td>
                                            <td><?php echo $record['password']?></td>
                                            <td><?php echo $record['authority']?></td>
                                            <td>
                                            <a href="<?php echo base_url();?>index.php/admin/user/deleteuser?id=<?php echo $record['id']?>">
                                               <i class="glyphicon glyphicon-trash"></i>  </a>
                                            <a href="<?php echo base_url();?>index.php/admin/user/edituser?id=<?php echo $record['id']?>"> <i class="glyphicon glyphicon-pencil"></i></a>
                                            <a href="<?php echo base_url();?>index.php/admin/user/unblockusers?id=<?php echo $record['id']?>">  <button class="btn btn-danger" >Un Block</button></a>
                                            </td>
                                        <?php }  }
                                elseif($this->session->userdata('user_id')==2){if($record['enabled']=='1' & $record['authorityId']!= '1'){?>

                                    <td><?php echo $record['userName']?></td>
                                    <td><?php echo $record['password']?></td>
                                    <td><?php echo $record['authority']?></td>
                                    <td>
                                    <a href="<?php echo base_url();?>index.php/admin/user/edituser?id=<?php echo $record['id']?>"> <i class="glyphicon glyphicon-pencil"></i></a>

                                    <a href="<?php echo base_url();?>index.php/admin/user/blockusers?id=<?php echo $record['id']?>"><button class="btn btn-default" >Block</button></a>
                                    </td>
                                        <?php }elseif($record['enabled']=='0'){?>
                                                                        <td><?php echo $record['userName']?></td>
                                            <td><?php echo $record['password']?></td>
                                            <td><?php echo $record['authority']?></td>
                                            <td>
                                    <a href="<?php echo base_url();?>index.php/admin/user/edituser?id=<?php echo $record['id']?>"> <i class="glyphicon glyphicon-pencil"></i></a>

                                    <a href="<?php echo base_url();?>index.php/admin/user/unblockusers?id=<?php echo $record['id']?>">  <button class="btn btn-danger" >Un Block</button></a>


                                    </td>
                                <?php }  }

                                    elseif($this->session->userdata('user_id')==3){if($record['enabled']=='1' & $record['authorityId']!= '1'){?>

                                    <td><?php echo $record['userName']?></td >

                                        <?php }  }?>

                                </tr>
                            <?php }?>

                            </tbody>
                        </table>
                    </div>
                </div>

            <?php }?>
            <?php if ($this->input->get('page')==2)
            {?>
                <div class="col-lg-12">
                    <h2>Professional users</h2>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>UserName</th>
                                <th>password</th>
                                <th>authority</th>
                                <th>add</th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php echo form_open('admin/user/create'); ?>
                                <tr>
                                    <input type="hidden" name="action" value="create_user">
                                    <td ><input class="form-control" style="width:100%" type="text" name="username"></td>
                                    <td ><input class="form-control" style="width:100%" type="text" name="password"></td>
                                    <td >
                                            <select class="form-control" name="authority">
                                                <?php foreach($records as $record){?>

                                                <option value="<?php echo $record['authorityId'];?>"><?php echo $record['authority'];?></option>
                                                <?php }?>
                                            </select>
                                          </td>
                                    <td><button >Add User</button></td>

                                </tr>
</form>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php }?>


            <?php if ($this->input->get('page')==3)
            {?>
                <div class="col-lg-12">
                    <h2>Features</h2>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>Action</th>                             </tr>
                            </thead>
                            <tbody>
                            <td ><input style="width:100%" type="text" name="category"></td>
                            <td><button >add category</button></td>

                            <?php foreach ($records as $record){ ?>
                                <tr>
                                    <td><?php echo $record['cat_name']?></td>

                                    <td>      <a href="<?php echo base_url();?>index.php/admin/feature/deletefeature?id=<?php echo $record['id']?>&feature=category"
                                        >     <i class="glyphicon glyphicon-trash"></i>  </a>
                                        <a href="<?php echo base_url();?>index.php/admin/feature/editfeature?id=<?php echo $record['id']?>"> <i class="glyphicon glyphicon-pencil"></i></a> </td>

                                </tr>
                            <?php }?>

                            </tbody>
                        </table>
                    </div>
                </div>
            <?php }?>
        </div>
        <!-- /.row -->

    </div>
</div>
<!-- /#wrapper -->

