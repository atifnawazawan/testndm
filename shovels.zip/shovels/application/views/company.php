
<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Tables
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a>
                    </li>
                    <li class="active">
                        <i class="fa fa-table"></i> Tables
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <?php if ($this->input->get('page')==1){
                $this->Model_form->company_form($records);
            }
            elseif ($this->input->get('page')=='loc')
            {
                $this->Model_form->location_form($records); }
            elseif($this->input->get('page')=='diesel'){
                $this->Model_form->diesel_form($records,$shov);
            }
            elseif($this->input->get('page')=='shovown'){
                $this->Model_form->shovown_form($records);
            }
            elseif($this->input->get('page')=='expens'){
                $this->Model_form->expense_form($records);
            }
            elseif($this->input->get('page')=='paytake'){
                $this->Model_form->paytake_form($records);
            }
            elseif($this->input->get('page')=='paydet'){
                $this->Model_form->paydet_form($records);
            }
            elseif($this->input->get('page')=='showok'){
                $this->Model_form->showok_form($records);
            }


            ?>

        </div>
        <!-- /.row -->

    </div>
</div>
<!-- /#wrapper -->