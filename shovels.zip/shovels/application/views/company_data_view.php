
<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <?php foreach($records as $record)
                    echo $record['comp_name'];?>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a>
                    </li>
                    <li class="active">
                        <i class="fa fa-table"></i> Tables
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">


            <?php if ($this->input->get('page')==2)
            {?>
                <div class="col-lg-12">
                    <h2>Add details</h2>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>Date</th>
                                <th>Time Sheet No</th>
                                <th>details</th>
                                <th>Trip/m3/Hours</th>
                                <th>Rate</th>
                                <th>Total Amount</th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php echo form_open('data/companydata'); ?>
                            <tr>
                                <input type="hidden" name="action" value="add_company_data">
                                <input type="hidden" name="compid" value="<?php echo $record['comp_id'];?>">
                                <td ><input class="form-control" style="width:100%" type="date" name="date"></td>
                                <td ><input class="form-control" style="width:100%" type="text" name="timesheet"></td>
                                <td ><input class="form-control" style="width:100%" type="text" name="detail"></td>
                                <td ><input class="form-control" style="width:100%" type="text" name="trip"></td>
                                <td ><input class="form-control" style="width:100%" type="number" name="rate"></td>
                                <td ><input class="form-control" style="width:100%" type="text" name="totamount"></td>


                            </tr>
                            </tbody>
                        </table>
                        <input class="btn btn-success" type="submit" name="submit" value="Add Details" />

                        </form>

                    </div>
                </div>
                <h2>Previous details</h2>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th>Date</th>
                            <th>Time Sheet No</th>
                            <th>details</th>
                            <th>Trip/m3/Hours</th>
                            <th>Rate</th>
                            <th>Total Amount</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach($data as $dat){?>
                        <tr>
                            <td ><?php echo $dat['date'];?></td>
                            <td ><?php echo $dat['timesheet_no'];?></td>
                            <td ><?php echo $dat['details'];?></td>
                            <td ><?php echo $dat['trip_m3_hour'];?></td>
                            <td ><?php echo $dat['rate'];?></td>
                            <td ><?php echo $dat['totalamount'];?></td>


                        </tr>
                        <?php }?>
                        </tbody>
                    </table>



                </div>
            <?php }?>


        </div>
        <!-- /.row -->

    </div>
</div>
<!-- /#wrapper -->

